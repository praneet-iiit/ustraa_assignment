# The following code is submitted by Praneet Bhatnagar for assessment by Team Ustraa/Happily Unmarried.

import mysql.connector
import random

#------------------------------------Generates Random Lists ------------------------------------------------
def generate_lists(data):
    global output_list
    output_list = []
    super_eight_teams = []
    non_super_eight_teams = []

    for team_x in data:
        if team_x[2] == 'Y':
            super_eight_teams.append(team_x)
        else:
            non_super_eight_teams.append(team_x)

    group_id = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

    for i in group_id:
        #Shuffling List randomly in each iteration
        random.shuffle(super_eight_teams)
        state_constraint = []
        superteam = super_eight_teams.pop()
        state_constraint.append(superteam[1])
        print("\n*** Group " + i + " ***")
        print(superteam[0] + " (" + superteam[1] + ")")
        tup_i = (i,)
        output_list.append(tup_i + superteam)

        j = 0

        counter = 0

        while (j < 3):
            # Shuffling List randomly in each iteration
            random.shuffle(non_super_eight_teams)
            team = non_super_eight_teams.pop()

            if (team[1] in state_constraint):
                #If any team exists in group with same state, undo the pop operation and reshuffle
                non_super_eight_teams.append(team)
                random.shuffle(non_super_eight_teams)
                #counter Counts number of times program has been stuck by the constraint
                counter += 1
            else:
                state_constraint.append(team[1])
                print(team[0] + " (" + team[1] + ")")
                tup_i = (i,)
                output_list.append(tup_i + team)
                j += 1

            #prevents while loop from entering infinite looping state and redirects the flow to a new start
            if (counter > len(output_list)):
                print("\n***********Unable to complete list due to State-constraint**************")
                print("----> as Teams randomly left with same states----->")
                print(non_super_eight_teams)
                print("\n\n\n*********************** RESTARTING TASK ***************************************")
                generate_lists(data)
                print_menu()

#--------------------------------------Saves Generated Lists into DB making required changes---------------------------------------------
def save_into_db(output_list):
    db = mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="qwertylove",
        database="new_schema"
    )

    cursor = db.cursor()

    cursor.execute("SHOW TABLES LIKE 'generated_grouped_clubs';")
    data = cursor.fetchall()

    if data:
        print("------generated_grouped_clubs Table Already Exists------")
        cursor.execute("DROP TABLE generated_grouped_clubs;")
        print("------Existing generated_grouped_clubs Table Dropped------")

    cursor.execute("CREATE TABLE generated_grouped_clubs (group_id char(1), club_name varchar(99), state varchar(50), s_e_qualified char(1));")
    print("----------Created New Table generated_grouped_clubs-------------------")

    query_string = "INSERT INTO generated_grouped_clubs (group_id,club_name, state, s_e_qualified) VALUES (%s, %s,%s, %s)"
    cursor.executemany(query_string, output_list)
    db.commit()
    print(cursor.rowcount, " rows inserted into generated_grouped_clubs table.")

#-----------------------------------Prints MENU on Python Console--------------------------------------------
def print_menu():
    while (1):
        print("\n************ Do you wish to save the generated lists in Database? *****************")
        ch = input("Enter Y for Yes, N for No!")
        if ch == 'Y' or ch == 'y':
            save_into_db(output_list)
            exit()
        elif ch == 'N' or ch == 'n':
            print("\n\n*******************The program will exit without saving list into Database.*****************")
            exit()
        else:
            print("\n\n**********Wrong Input**********")

#------------------------------Driver Code-----------------------------------------
def main():
    db_user = input("Enter the user of database- ")
    db_pwd = input("Enter the password for user- ")
    db_name = input("Enter the name of database- ")

    db = mysql.connector.connect(
        host="127.0.0.1",
        user=db_user,
        password=db_pwd,
        database=db_name,
        auth_plugin='mysql_native_password'
    )
    cursor = db.cursor()


    cursor.execute("SELECT * FROM ustraa_clubs")

    data = cursor.fetchall()

    if data:
        generate_lists(data)
        print_menu()
    else:
        print("Data does not exist in DB, please import data using csv_import.py")


if __name__ == "__main__":
    main()


# The following code is submitted by Praneet Bhatnagar for assessment by Team Ustraa/Happily Unmarried.