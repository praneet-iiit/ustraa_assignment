#The following code is submitted by Praneet Bhatnagar for assessment by Team Ustraa/Happily Unmarried.


import mysql.connector
import csv

csv_path=input(r'''Enter path to CSV file - in following format --- C:\Users\Praneet Bhatnagar\OneDrive\Ustraa Assignment\ustraa_clubs_dataset.csv''')

with open(csv_path, newline='') as f:
    reader = csv.reader(f)
    input_data = list(reader)

input_data=input_data[1::]

db_user=input("Enter the user of database- ")
db_pwd=input("Enter the password for user- ")
db_name=input("Enter the name of database- ")

db = mysql.connector.connect(
        host="127.0.0.1",
        user=db_user,
        password=db_pwd,
        database=db_name,
        auth_plugin='mysql_native_password'
    )

cursor = db.cursor()

cursor.execute("SHOW TABLES LIKE 'ustraa_clubs';")
data = cursor.fetchall()

if data:
        print("------ustraa_clubs Table Already Exists------")
        cursor.execute("DROP TABLE ustraa_clubs;")
        print("------Existing ustraa_clubs Table Dropped------")

cursor.execute("CREATE TABLE ustraa_clubs (club_name varchar(99), state varchar(50), s_e_qualified char(1));")
print("----------Created New Table ustraa_clubs-------------------")

sum_rowcount=0

for row in input_data:
    query_string = "INSERT INTO ustraa_clubs (club_name, state, s_e_qualified) VALUES (%s, %s,%s)"
    cursor.execute(query_string, row[1::])
    db.commit()
    sum_rowcount+=cursor.rowcount

print(sum_rowcount, " rows inserted into ustraa_clubs table.")


# The following code is submitted by Praneet Bhatnagar for assessment by Team Ustraa/Happily Unmarried.